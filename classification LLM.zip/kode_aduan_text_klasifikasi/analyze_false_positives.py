# analyze_false_positives.py
from enhanced_classifyaduan import EnhancedAduanClassifier
import pandas as pd
import re

def analyze_false_positives():
    """Analyze false positives untuk understanding pattern"""
    print("=== FALSE POSITIVES ANALYSIS ===")
    
    df = pd.read_csv('penting/aduan_approved.csv')
    
    # Prepare true labels
    if 'corrected_type' in df.columns:
        y_true = df['corrected_type'].fillna(df['aduan_type'])
    else:
        y_true = df['aduan_type']
    
    classifier = EnhancedAduanClassifier()
    classifier.load_ml_model()
    
    false_positives = []
    
    for idx, row in df.iterrows():
        text = row['text']
        true_label = y_true.iloc[idx]
        
        classification, score, ml_prob = classifier.classify_text(text)
        
        if classification == 'aduan_text' and true_label == 'not_aduan_text':
            # Analyze why it was misclassified
            processed = classifier.preprocess_text(text)
            rule_score = classifier.calculate_rule_score(text)
            
            # Find triggering keywords
            triggering_keywords = []
            for keyword in classifier.WEAK_INDICATORS:
                if re.search(rf'\b{keyword}\b', processed):
                    triggering_keywords.append(keyword)
            
            false_positives.append({
                'text': text,
                'processed': processed,
                'rule_score': rule_score,
                'ml_prob': ml_prob,
                'triggering_keywords': triggering_keywords,
                'word_count': len(processed.split())
            })
    
    print(f"Total False Positives: {len(false_positives)}")
    
    # Analyze patterns
    if false_positives:
        fp_df = pd.DataFrame(false_positives)
        
        print("\nTop Triggering Keywords in False Positives:")
        all_keywords = []
        for keywords in fp_df['triggering_keywords']:
            all_keywords.extend(keywords)
        
        from collections import Counter
        keyword_counts = Counter(all_keywords)
        for keyword, count in keyword_counts.most_common(10):
            print(f"  {keyword}: {count} times")
        
        print(f"\nAverage Rule Score: {fp_df['rule_score'].mean():.2f}")
        print(f"Average ML Probability: {fp_df['ml_prob'].mean():.2f}")
        print(f"Average Word Count: {fp_df['word_count'].mean():.1f}")
        
        # Show most common false positive patterns
        print("\nSample False Positives with Analysis:")
        for i, fp in enumerate(false_positives[:5]):
            print(f"\n{i+1}. {fp['text'][:80]}...")
            print(f"   Processed: {fp['processed'][:60]}...")
            print(f"   Rule Score: {fp['rule_score']:.2f}, ML Prob: {fp['ml_prob']:.2f}")
            print(f"   Triggers: {fp['triggering_keywords']}")

if __name__ == "__main__":
    analyze_false_positives()