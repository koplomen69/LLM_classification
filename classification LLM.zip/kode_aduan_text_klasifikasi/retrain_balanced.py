# retrain_balanced.py
from enhanced_classifyaduan import EnhancedAduanClassifier
import pandas as pd
import numpy as np
from sklearn.utils import resample
import joblib

def balance_training_data():
    """Balance the training data"""
    print("=== BALANCING TRAINING DATA ===")
    
    df = pd.read_csv('penting/aduan_approved.csv')
    
    # Prepare labels
    if 'corrected_type' in df.columns:
        labels = df['corrected_type'].fillna(df['aduan_type'])
    else:
        labels = df['aduan_type']
    
    df['final_label'] = labels
    y = (labels == 'aduan_text').astype(int)
    
    print(f"Before balancing:")
    print(f"  Not Aduan: {len(df[df['final_label'] == 'not_aduan_text'])}")
    print(f"  Aduan: {len(df[df['final_label'] == 'aduan_text'])}")
    
    # Separate classes
    df_majority = df[df['final_label'] == 'not_aduan_text']
    df_minority = df[df['final_label'] == 'aduan_text']
    
    # Upsample minority class
    df_minority_upsampled = resample(
        df_minority,
        replace=True,  # sample with replacement
        n_samples=len(df_majority),  # match majority class
        random_state=42
    )
    
    # Combine balanced dataset
    df_balanced = pd.concat([df_majority, df_minority_upsampled])
    
    print(f"After balancing:")
    print(f"  Not Aduan: {len(df_balanced[df_balanced['final_label'] == 'not_aduan_text'])}")
    print(f"  Aduan: {len(df_balanced[df_balanced['final_label'] == 'aduan_text'])}")
    
    return df_balanced

def retrain_balanced_model():
    """Retrain dengan balanced data"""
    print("\n=== RETRAINING WITH BALANCED DATA ===")
    
    # Get balanced data
    df_balanced = balance_training_data()
    
    classifier = EnhancedAduanClassifier()
    
    # Prepare features and labels
    texts = df_balanced['text'].apply(classifier.preprocess_text)
    y_balanced = (df_balanced['final_label'] == 'aduan_text').astype(int)
    
    # Enhanced vectorizer
    from sklearn.feature_extraction.text import TfidfVectorizer
    
    classifier.vectorizer = TfidfVectorizer(
        max_features=1000,
        ngram_range=(1, 2),
        min_df=3,  # Increase to ignore rare terms
        max_df=0.7,  # Decrease to ignore very common terms
        stop_words=None
    )
    
    X_balanced = classifier.vectorizer.fit_transform(texts)
    
    print(f"Balanced feature matrix shape: {X_balanced.shape}")
    
    # Train dengan class weight yang explicit
    from sklearn.ensemble import RandomForestClassifier
    
    classifier.ml_model = RandomForestClassifier(
        n_estimators=150,
        max_depth=15,
        min_samples_split=10,
        min_samples_leaf=4,
        class_weight='balanced',  # Important for imbalanced data
        random_state=42
    )
    
    classifier.ml_model.fit(X_balanced, y_balanced)
    classifier.is_trained = True
    
    # Save model
    joblib.dump(classifier.ml_model, 'ml_models/balanced_aduan_classifier_model.pkl')
    joblib.dump(classifier.vectorizer, 'ml_models/balanced_aduan_vectorizer.pkl')
    
    # Update model paths in classifier
    classifier.model_path = 'ml_models/balanced_aduan_classifier_model.pkl'
    classifier.vectorizer_path = 'ml_models/balanced_aduan_vectorizer.pkl'
    
    print("✅ Balanced model trained and saved!")
    
    return classifier

def test_balanced_model():
    """Test the balanced model"""
    print("\n=== TESTING BALANCED MODEL ===")
    
    classifier = EnhancedAduanClassifier()
    
    # Load balanced model
    try:
        classifier.ml_model = joblib.load('ml_models/balanced_aduan_classifier_model.pkl')
        classifier.vectorizer = joblib.load('ml_models/balanced_aduan_vectorizer.pkl')
        classifier.is_trained = True
        classifier.model_path = 'ml_models/balanced_aduan_classifier_model.pkl'
        classifier.vectorizer_path = 'ml_models/balanced_aduan_vectorizer.pkl'
        print("Balanced model loaded successfully!")
    except:
        print("Balanced model not found, training new one...")
        classifier = retrain_balanced_model()
    
    # Test dengan sample texts
    test_texts = [
        "Telyu! LMS error gabisa login",  # Should be aduan
        "rekomendasi cafe enak dong",     # Should not aduan
        "nilai KHS saya salah",           # Should be aduan  
        "bagi info loker ya",             # Should not aduan
        "toilet rusak parah",             # Should be aduan
    ]
    
    for text in test_texts:
        classification, score, ml_prob = classifier.classify_text(text)
        print(f"Text: {text}")
        print(f"  Result: {classification} (score: {score:.2f}, ML prob: {ml_prob:.2f})")

if __name__ == "__main__":
    classifier = retrain_balanced_model()
    test_balanced_model()