# retrain_model.py
from enhanced_classifyaduan import EnhancedAduanClassifier
import pandas as pd
import numpy as np

def analyze_training_data_quality():
    """Analyze quality of training data"""
    print("=== TRAINING DATA ANALYSIS ===")
    
    df = pd.read_csv('penting/aduan_approved.csv')
    
    print(f"Total samples: {len(df)}")
    
    # Check label distribution
    if 'corrected_type' in df.columns:
        labels = df['corrected_type'].fillna(df['aduan_type'])
    else:
        labels = df['aduan_type']
    
    label_counts = labels.value_counts()
    print(f"Label distribution: {label_counts.to_dict()}")
    
    # Check for class imbalance
    aduan_ratio = label_counts.get('aduan_text', 0) / len(df)
    print(f"Aduan ratio: {aduan_ratio:.2f}")
    
    # Analyze text length
    df['text_length'] = df['text'].str.len()
    print(f"Average text length: {df['text_length'].mean():.1f} chars")
    
    return df

def retrain_with_better_features():
    """Retrain model dengan improved feature engineering"""
    print("\n=== RETRAINING WITH BETTER FEATURES ===")
    
    classifier = EnhancedAduanClassifier()
    
    # Custom training dengan better parameters
    df = pd.read_csv('penting/aduan_approved.csv')
    
    # Prepare labels
    if 'corrected_type' in df.columns:
        labels = df['corrected_type'].fillna(df['aduan_type'])
    else:
        labels = df['aduan_type']
    
    y = (labels == 'aduan_text').astype(int)
    
    # Enhanced preprocessing untuk training
    texts = df['text'].apply(classifier.preprocess_text)
    
    # Use better vectorizer parameters
    from sklearn.feature_extraction.text import TfidfVectorizer
    
    classifier.vectorizer = TfidfVectorizer(
        max_features=1500,  # Increased features
        ngram_range=(1, 3),  # Include trigrams
        min_df=2,  # Ignore very rare terms
        max_df=0.8,  # Ignore too common terms
        stop_words=None
    )
    
    X = classifier.vectorizer.fit_transform(texts)
    
    print(f"Feature matrix shape: {X.shape}")
    
    # Use better model parameters
    from sklearn.ensemble import RandomForestClassifier
    
    classifier.ml_model = RandomForestClassifier(
        n_estimators=200,  # More trees
        max_depth=20,  # Deeper trees
        min_samples_split=5,
        min_samples_leaf=2,
        class_weight='balanced',
        random_state=42
    )
    
    classifier.ml_model.fit(X, y)
    classifier.is_trained = True
    
    # Save model
    import joblib
    joblib.dump(classifier.ml_model, classifier.model_path)
    joblib.dump(classifier.vectorizer, classifier.vectorizer_path)
    
    # Evaluate training performance
    train_predictions = classifier.ml_model.predict_proba(X)[:, 1]
    print(f"Training predictions range: {train_predictions.min():.3f} - {train_predictions.max():.3f}")
    
    print("✅ Model retrained with better features!")

if __name__ == "__main__":
    analyze_training_data_quality()
    retrain_with_better_features()