# train_aduan_model.py
from enhanced_classifyaduan import EnhancedAduanClassifier

def train_model():
    print("Training ML model for aduan classification...")
    
    classifier = EnhancedAduanClassifier()
    
    # Train dengan data yang sudah di-label
    classifier.train_ml_model('aduan_approved.csv')
    
    print("\nModel training completed!")
    print("You can now use the enhanced classifier in your main application.")

if __name__ == "__main__":
    train_model()