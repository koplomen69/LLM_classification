# test_enhanced_model.py - FIXED VERSION
from enhanced_classifyaduan import EnhancedAduanClassifier
from classifyaduan import classify_dataset
import pandas as pd

def test_individual_texts():
    """Test model dengan berbagai contoh text"""
    print("=== INDIVIDUAL TEXT TESTING ===")
    
    classifier = EnhancedAduanClassifier()
    classifier.load_ml_model()
    
    test_cases = [
        # Should be ADUAN
        ("Telyu! LMS error gabisa login dari tadi", "aduan_text"),
        ("nilai saya di KHS kok salah ya?", "aduan_text"),
        ("toilet di gedung 4 rusak parah", "aduan_text"),
        ("bpp semester ini kok telat bayarnya?", "aduan_text"),
        ("wifi kampus lemot banget hari ini", "aduan_text"),
        
        # Should be NON-ADUAN
        ("Telyu! rekomendasi cafe yang enak dong", "not_aduan_text"),
        ("ada yang punya info loker ga?", "not_aduan_text"), 
        ("selamat pagi semuanya!", "not_aduan_text"),
        ("bagi pengalaman magang dong", "not_aduan_text"),
        ("cafe sekitar kampus yang bagus apa ya?", "not_aduan_text"),
        
        # Borderline cases
        ("Telyu! gimana cara daftar magang?", "not_aduan_text"),
        ("kenapa ya nilai belum keluar?", "aduan_text"),
    ]
    
    correct = 0
    total = len(test_cases)
    
    for text, expected in test_cases:
        classification, score, ml_prob = classifier.classify_text(text)
        status = "✅" if classification == expected else "❌"
        
        print(f"{status} Text: {text}")
        print(f"   Expected: {expected}, Got: {classification}")
        
        # FIX: Handle ml_prob formatting properly
        if ml_prob is not None:
            print(f"   Score: {score:.2f}, ML Prob: {ml_prob:.2f}")
        else:
            print(f"   Score: {score:.2f}, ML Prob: N/A")
        
        if classification == expected:
            correct += 1
    
    accuracy = (correct / total) * 100
    print(f"\n🎯 Test Accuracy: {accuracy:.1f}% ({correct}/{total})")

def test_with_validation_data():
    """Test dengan data validation dari aduan_approved.csv"""
    print("\n=== VALIDATION DATA TESTING ===")
    
    # Use part of approved data for testing
    df = pd.read_csv('penting/aduan_approved.csv')
    test_samples = df.sample(min(20, len(df)))  # Test dengan 20 sample
    
    classifier = EnhancedAduanClassifier()
    classifier.load_ml_model()
    
    correct = 0
    total = len(test_samples)
    
    for idx, row in test_samples.iterrows():
        text = row['text']
        expected = row['corrected_type'] if pd.notna(row.get('corrected_type')) else row['aduan_type']
        
        classification, score, ml_prob = classifier.classify_text(text)
        status = "✅" if classification == expected else "❌"
        
        print(f"{status} {text[:60]}...")
        print(f"   Expected: {expected}, Got: {classification}")
        
        if classification == expected:
            correct += 1
    
    accuracy = (correct / total) * 100
    print(f"\n🎯 Validation Accuracy: {accuracy:.1f}% ({correct}/{total})")

def compare_old_vs_new():
    """Bandingkan hasil old classifier vs new enhanced classifier"""
    print("\n=== OLD vs NEW COMPARISON ===")
    
    # Test dengan sample data
    sample_texts = [
        "Telyu! LMS error nih",
        "rekomendasi cafe dong",
        "nilai KHS saya salah",
        "bagi info loker ya",
        "toilet rusak di gedung 1"
    ]
    
    from enhanced_classifyaduan import enhanced_classify_aduan
    
    print("Text -> Old Result | New Result")
    print("-" * 50)
    
    for text in sample_texts:
        # Old classifier (simulate)
        old_result = "aduan_text" if any(kw in text.lower() for kw in ['error', 'salah', 'rusak']) else "not_aduan_text"
        
        # New classifier
        new_result = enhanced_classify_aduan(text)
        
        print(f"{text[:30]}... -> {old_result:12} | {new_result:12}")

def run_production_test():
    """Test dengan dataset penuh seperti di production"""
    print("\n=== PRODUCTION SIMULATION TEST ===")
    
    try:
        # Test dengan dataset kecil dulu
        result_df = classify_dataset('aduan_raw.csv')
        
        print("✅ Production test completed!")
        print(f"📊 Results: {len(result_df)} confident aduan texts identified")
        
        # Show some samples
        print("\nSample confident aduan texts:")
        for idx, row in result_df.head(5).iterrows():
            print(f"  - {row['text'][:80]}...")
            
    except Exception as e:
        print(f"❌ Production test failed: {e}")
        import traceback
        print(f"Error details: {traceback.format_exc()}")

def debug_model_decisions():
    """Debug untuk melihat bagaimana model mengambil keputusan"""
    print("\n=== MODEL DECISION DEBUG ===")
    
    classifier = EnhancedAduanClassifier()
    classifier.load_ml_model()
    
    debug_texts = [
        "Telyu! LMS error gabisa login dari tadi",
        "rekomendasi cafe yang enak dong",
        "nilai KHS saya kok salah ya?"
    ]
    
    for text in debug_texts:
        print(f"\n🔍 Analyzing: {text}")
        
        # Rule-based score
        rule_score = classifier.calculate_rule_score(text)
        print(f"   Rule Score: {rule_score:.2f}")
        
        # ML probability - FIXED FORMATTING
        ml_prob = classifier.ml_predict(text)
        if ml_prob is not None:
            print(f"   ML Probability: {ml_prob:.2f}")
        else:
            print(f"   ML Probability: N/A")
        
        # Final classification
        classification, final_score, final_ml_prob = classifier.classify_text(text)
        print(f"   Final: {classification} (score: {final_score:.2f})")

if __name__ == "__main__":
    print("🧪 COMPREHENSIVE MODEL TESTING")
    print("=" * 50)
    
    test_individual_texts()
    test_with_validation_data() 
    compare_old_vs_new()
    debug_model_decisions()  # Added debug function
    run_production_test()