import os
import re
import pandas as pd
import time
from tqdm import tqdm as original_tqdm
from langchain.prompts import PromptTemplate
from langchain_community.llms import LlamaCpp
from langchain_core.output_parsers import StrOutputParser
from prompt_manager import prompt_manager

# ✅ PERBAIKAN: Custom tqdm yang aman untuk Flask
def safe_tqdm(*args, **kwargs):
    """Safe tqdm untuk environment Flask"""
    if 'WERKZEUG_RUN_MAIN' in os.environ or 'FLASK_APP' in os.environ:
        # Nonaktifkan progress bar di web environment
        kwargs['disable'] = True
    return original_tqdm(*args, **kwargs)

# Ganti tqdm dengan safe_tqdm
tqdm = safe_tqdm

# ==================== OPTIMIZER CLASSES ====================

class UniversalPromptOptimizer:
    def __init__(self):
        self.component_cache = {}
        self.model_profiles = {
            # Qwen series
            'qwen': {'optimal_context': 16000, 'preferred_format': 'chatml'},
            'qwen2': {'optimal_context': 16000, 'preferred_format': 'chatml'},
            'qwen3': {'optimal_context': 16000, 'preferred_format': 'chatml'},
            
            # Llama series
            'llama': {'optimal_context': 4096, 'preferred_format': 'llama'},
            'llama2': {'optimal_context': 4096, 'preferred_format': 'llama'},
            'llama3': {'optimal_context': 8192, 'preferred_format': 'llama'},
            
            # Mistral series
            'mistral': {'optimal_context': 8192, 'preferred_format': 'mistral'},
            'mixtral': {'optimal_context': 32768, 'preferred_format': 'mistral'},
            
            # Phi series
            'phi': {'optimal_context': 2048, 'preferred_format': 'chatml'},
            
            # Gemma series
            'gemma': {'optimal_context': 8192, 'preferred_format': 'chatml'},
            
            # Default profile
            'default': {'optimal_context': 4096, 'preferred_format': 'chatml'}
        }
    
    def detect_model_family(self, model_name):
        """Detect model family dari nama model"""
        model_lower = model_name.lower()
        
        for family in self.model_profiles:
            if family in model_lower and family != 'default':
                return family
        
        return 'default'
    
    def get_model_profile(self, model_name):
        """Dapatkan profile optimasi untuk model tertentu"""
        family = self.detect_model_family(model_name)
        return self.model_profiles.get(family, self.model_profiles['default'])
    
    def optimize_prompt_for_model(self, text, config_id=None, model_name="default", max_tokens_override=None):
        """Optimasi prompt untuk model spesifik"""
        
        # Dapatkan model profile
        profile = self.get_model_profile(model_name)
        optimal_context = max_tokens_override or profile['optimal_context']
        max_prompt_tokens = int(optimal_context * 0.7)  # 70% untuk prompt, 30% untuk output
        
        print(f"🎯 Optimizing for {model_name} | Context: {optimal_context} | Family: {self.detect_model_family(model_name)}")
        
        # 1. Dapatkan base prompt dari database
        if config_id not in self.component_cache:
            self.component_cache[config_id] = self.load_prompt_components(config_id)
        
        components = self.component_cache[config_id]
        
        # 2. Bangun optimized prompt berdasarkan model family
        optimized_prompt = self.build_model_specific_prompt(
            components, text, model_name, max_prompt_tokens
        )
        
        estimated_tokens = len(optimized_prompt) // 4
        print(f"🔧 {model_name} Optimized: {len(optimized_prompt)} chars (~{estimated_tokens} tokens)")
        
        return optimized_prompt
    
    def build_model_specific_prompt(self, components, text, model_name, max_tokens):
        """Bangun prompt spesifik untuk model"""
        
        model_family = self.detect_model_family(model_name)
        
        # Template berdasarkan model family
        templates = {
            'qwen': self.build_chatml_prompt,
            'qwen2': self.build_chatml_prompt,
            'qwen3': self.build_chatml_prompt,
            'llama': self.build_llama_prompt,
            'llama2': self.build_llama_prompt, 
            'llama3': self.build_llama_prompt,
            'mistral': self.build_mistral_prompt,
            'mixtral': self.build_mistral_prompt,
            'komodo': self.build_mistral_prompt,
            'phi': self.build_chatml_prompt,
            'gemma': self.build_chatml_prompt,
            'default': self.build_chatml_prompt
        }
        
        builder = templates.get(model_family, self.build_chatml_prompt)
        prompt = builder(components, text, max_tokens)
        
        # Jika masih terlalu panjang, gunakan aggressive compression
        if len(prompt) > max_tokens:
            prompt = self.build_aggressive_prompt(text, model_family)
            
        return prompt
    
    def build_chatml_prompt(self, components, text, max_tokens):
        """ChatML format untuk Qwen, Phi, Gemma, dll"""
        prompt_parts = []
        
        # System message
        system_content = "Anda adalah sistem klasifikasi untuk keluhan mahasiswa. "
        if 'base' in components:
            system_content += self.compress_instructions(components['base'].content)
        prompt_parts.append(f"<|im_start|>system\n{system_content}<|im_end|>")
        
        # Format instruction
        prompt_parts.append("<|im_start|>system\nFORMAT: Direktorat: [nama], Keyword: [kata_kunci]<|im_end|>")
        
        # Direktorat list
        if 'keywords' in components:
            direktorat_section = self.extract_direktorat_list(components['keywords'].content)
            prompt_parts.append(f"<|im_start|>system\n{direktorat_section}<|im_end|>")
        
        # Examples
        if 'examples' in components:
            best_examples = self.select_best_examples(components['examples'].content, count=2)
            prompt_parts.append(f"<|im_start|>system\nCONTOH:\n{best_examples}<|im_end|>")
        
        # User input
        prompt_parts.append(f"<|im_start|>user\nTeks: {text}<|im_end|>")
        prompt_parts.append("<|im_start|>assistant")
        
        return '\n'.join(prompt_parts)
    
    def build_llama_prompt(self, components, text, max_tokens):
        """Llama format"""
        prompt_parts = ["<s>[INST] <<SYS>>"]
        
        # System instruction
        if 'base' in components:
            system_content = self.compress_instructions(components['base'].content)
            prompt_parts.append(system_content)
        
        prompt_parts.append("Format: Direktorat: [nama], Keyword: [kata_kunci]")
        
        # Direktorat list
        if 'keywords' in components:
            direktorat_section = self.extract_direktorat_list(components['keywords'].content)
            prompt_parts.append(direktorat_section)
        
        # Examples
        if 'examples' in components:
            best_examples = self.select_best_examples(components['examples'].content, count=2)
            prompt_parts.append(f"Contoh:\n{best_examples}")
        
        prompt_parts.append("<</SYS>>")
        
        # User input
        prompt_parts.append(f"Klasifikasi: {text} [/INST]")
        
        return '\n'.join(prompt_parts)
    
    def build_mistral_prompt(self, components, text, max_tokens):
        """Mistral format"""
        prompt_parts = ["[INST]"]
        
        # System instruction
        if 'base' in components:
            system_content = self.compress_instructions(components['base'].content)
            prompt_parts.append(system_content)
        
        prompt_parts.append("Format: Direktorat: [nama], Keyword: [kata_kunci]")
        
        # Direktorat list
        if 'keywords' in components:
            direktorat_section = self.extract_direktorat_list(components['keywords'].content)
            prompt_parts.append(direktorat_section)
        
        # Examples  
        if 'examples' in components:
            best_examples = self.select_best_examples(components['examples'].content, count=2)
            prompt_parts.append(f"Contoh:\n{best_examples}")
        
        # User input
        prompt_parts.append(f"Teks: {text} [/INST]")
        
        return '\n'.join(prompt_parts)
    
    def build_aggressive_prompt(self, text, model_family):
        """Prompt sangat minimal"""
        base_prompt = f"Klasifikasi: {text}\nFormat: Direktorat: [nama], Keyword: [kata_kunci]"
        
        if model_family in ['qwen', 'qwen2', 'qwen3']:
            return f"<|im_start|>user\n{base_prompt}<|im_end|>\n<|im_start|>assistant"
        elif model_family in ['llama', 'llama2', 'llama3']:
            return f"<s>[INST] {base_prompt} [/INST]"
        elif model_family in ['mistral', 'mixtral', 'komodo']:
            return f"[INST] {base_prompt} [/INST]"
        else:
            return base_prompt

    def load_prompt_components(self, config_id):
        """Load komponen prompt dari database"""
        components = prompt_manager.get_config_components(config_id)
        return {comp.component_type: comp for comp in components if comp.is_enabled}
    
    def compress_instructions(self, instructions, max_lines=5):
        """Kompres instructions menjadi esensial saja"""
        lines = instructions.split('\n')
        essential_lines = []
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            if any(keyword in line.lower() for keyword in ['klasifikasi', 'format', 'output', 'direktorat']):
                essential_lines.append(line)
            elif len(essential_lines) < max_lines:
                essential_lines.append(line)
        
        return '\n'.join(essential_lines)
    
    def extract_direktorat_list(self, keywords_content):
        """Extract list direktorat yang simpel"""
        lines = keywords_content.split('\n')
        direktorat_lines = []
        
        for line in lines:
            if ':' in line and any(str(i) in line for i in range(1, 8)):
                # Format: "1. Akademik: krs, nilai, ipk"
                parts = line.split(':', 1)
                if len(parts) == 2:
                    direktorat = parts[0].strip()
                    # Hanya ambil 2-3 keyword utama
                    main_keywords = ', '.join(parts[1].strip().split(',')[:3])
                    direktorat_lines.append(f"{direktorat}: {main_keywords}")
        
        return "DIREKTORAT:\n" + '\n'.join(direktorat_lines[:7])  # Maks 7 direktorat
    
    def select_best_examples(self, examples_content, count=3):
        """Pilih contoh terbaik yang paling representatif"""
        examples = examples_content.split('\n\n')
        selected = []
        
        # Prioritaskan contoh dengan format yang konsisten
        for example in examples:
            if '→' in example and 'Direktorat:' in example:
                selected.append(example)
                if len(selected) >= count:
                    break
        
        return '\n\n'.join(selected)

class UniversalMemoryManager:
    def __init__(self, llm_instance):
        self.llm = llm_instance
        self.processed_count = 0
        self.reset_interval = 100  # Reset setiap 100 teks
    
    def process_with_memory_management(self, prompt):
        """Process dengan memory management"""
        output = self.llm.invoke(prompt)
        
        self.processed_count += 1
        
        # Reset context setiap interval tertentu untuk hindari memory leak
        if self.processed_count % self.reset_interval == 0:
            self.llm.reset()
            print("🔄 LLM context reset untuk memory management")
        
        return output

# ==================== MAIN CLASSIFICATION SYSTEM ====================

class ClassificationSystem:
    def __init__(self):
        self.optimizer = UniversalPromptOptimizer()
        self.memory_manager = None
        
    def log_message(self, msg, level="INFO", socketio=None):
        """Centralized logging function"""
        full_msg = f"[{level}] {msg}"
        print(full_msg)
        if socketio:
            try:
                socketio.emit('progress_update', {
                    'status': msg, 
                    'level': level
                }, namespace='/')
            except Exception as e:
                print(f"Socket emit error: {e}")

    def validate_file(self, file_path):
        """Validate input file"""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
            
        if not file_path.endswith(('.csv', '.xlsx')):
            raise ValueError("Only CSV and XLSX files are supported")
            
        return True

    def read_dataframe(self, file_path):
        """Read dataframe with multiple fallback strategies"""
        if file_path.endswith('.csv'):
            return self._read_csv(file_path)
        elif file_path.endswith('.xlsx'):
            return pd.read_excel(file_path, engine='openpyxl')
    
    def _read_csv(self, file_path):
        """Read CSV with multiple attempts"""
        attempts = [
            {"name": "Default", "kwargs": {}},
            {"name": "Python engine", "kwargs": {"engine": "python", "encoding": "utf-8"}},
            {"name": "UTF-8-sig", "kwargs": {"engine": "python", "encoding": "utf-8-sig"}},
            {"name": "Permissive", "kwargs": {
                "engine": "python", "encoding": "utf-8-sig",
                "on_bad_lines": "skip", "sep": None
            }}
        ]
        
        for attempt in attempts:
            try:
                df = pd.read_csv(file_path, **attempt['kwargs'])
                self.log_message(f"CSV read successful with {attempt['name']}")
                return df
            except Exception as e:
                self.log_message(f"Attempt {attempt['name']} failed: {e}", "WARNING")
                
        raise RuntimeError("All CSV reading attempts failed")

    def find_text_column(self, df):
        """Find appropriate text column in dataframe"""
        text_columns = [col for col in df.columns if 'text' in col.lower()]
        if text_columns:
            return text_columns[0]
        elif 'Text' in df.columns:
            return 'Text'
        else:
            raise ValueError(f"No text column found. Available: {df.columns.tolist()}")

    def load_checkpoint(self, checkpoint_path, total_rows):
        """Load existing checkpoint if available"""
        if not os.path.exists(checkpoint_path):
            return [None] * total_rows, 0
            
        try:
            checkpoint_df = pd.read_excel(checkpoint_path)
            results = [None] * total_rows
            
            for idx, row in checkpoint_df.iterrows():
                if (idx < total_rows and not pd.isna(row.get('Direktorat')) and 
                    not pd.isna(row.get('Keyword'))):
                    results[idx] = (row['Direktorat'], row['Keyword'])
                    
            start_idx = next((i for i, r in enumerate(results) if r is None), 0)
            return results, start_idx
            
        except Exception as e:
            self.log_message(f"Checkpoint load failed: {e}", "WARNING")
            return [None] * total_rows, 0

    def save_checkpoint(self, df, results, checkpoint_path):
        """Save progress checkpoint"""
        try:
            checkpoint_df = df.copy()
            checkpoint_df['Direktorat'] = [r[0] if r else None for r in results]
            checkpoint_df['Keyword'] = [r[1] if r else None for r in results]
            checkpoint_df.to_excel(checkpoint_path, index=False)
            return True
        except Exception as e:
            self.log_message(f"Checkpoint save failed: {e}", "WARNING")
            return False

    def process_single_text(self, text, llm, config_id):
        """Process dengan parser yang diperbaiki"""
        if not text or not text.strip():
            return "Uncategorized", "-"
            
        try:
            prompt = prompt_manager.build_prompt(text, config_id)
            
            print(f"🎯 Using YOUR custom prompt (config_id: {config_id})")
            print(f"📝 Text: {text[:80]}...")
            
            output = llm.invoke(prompt, max_tokens=200, temperature=0.3)
            print(f"📨 LLM Output: {output}")
            
            # GUNAKAN PARSER YANG BARU
            return parse_llm_output(output)
            
        except Exception as e:
            self.log_message(f"Text processing error: {e}", "ERROR")
            return "Error", str(e)

    def calculate_stats(self, start_time, processed_count, total_rows):
        """Calculate processing statistics"""
        elapsed = time.time() - start_time
        texts_per_second = processed_count / elapsed if elapsed > 0 else 0
        remaining = (total_rows - processed_count) / texts_per_second if texts_per_second > 0 else 0
        
        return {
            'processed': processed_count,
            'total': total_rows,
            'speed': f'{texts_per_second:.2f} texts/sec',
            'estimated_remaining': f'{remaining/60:.1f} minutes'
        }

    def classify_universal(self, file_path, socketio=None, config_id=None, 
                          model_name=None, ctx_size_override=None, 
                          benchmark_mode=False, strict_keyword_match=True):
        """Main universal classification function"""
        
        # Initialization
        self.log_message(f"Starting classification: {file_path}", socketio=socketio)
        start_time = time.time()
        
        # Validate and read data
        self.validate_file(file_path)
        df = self.read_dataframe(file_path)
        text_column = self.find_text_column(df)
        
        # Preprocessing
        self.log_message("Preprocessing texts...", socketio=socketio)
        df['processed_text'] = df[text_column].apply(preprocess_text)
        
        # Initialize LLM
        llm = init_llm_universal(model_name, ctx_size_override)
        self.memory_manager = UniversalMemoryManager(llm)
        
        # Checkpoint setup
        checkpoint_path = f"{os.path.splitext(file_path)[0]}_checkpoint.xlsx"
        results, start_idx = self.load_checkpoint(checkpoint_path, len(df))
        
        # ✅ PERBAIKAN: Gunakan safe_tqdm yang sudah didefinisikan di atas
        total_rows = len(df)
        for idx, row in tqdm(list(df.iterrows())[start_idx:], 
                           initial=start_idx, total=total_rows,
                           desc="Classifying"):
            
            text = row['processed_text']
            direktorat, keyword = self.process_single_text(text, llm, config_id)
            results[idx] = (direktorat, keyword)
            
            # Progress reporting
            if socketio and (idx % 10 == 0 or idx == total_rows - 1):
                stats = self.calculate_stats(start_time, idx + 1, total_rows)
                socketio.emit('progress_update', {
                    'status': f'Processing {idx + 1}/{total_rows}',
                    'percent': int((idx + 1) / total_rows * 100),
                    'stats': stats
                }, namespace='/')
            
            # Checkpoint saving
            if idx % 50 == 0:
                self.save_checkpoint(df, results, checkpoint_path)
        
        # Final processing
        df['Direktorat'] = [r[0] if r else "Uncategorized" for r in results]
        df['Keyword'] = [r[1] if r else "-" for r in results]
        
        # Apply strict keyword matching if enabled
        if strict_keyword_match:
            df = self.apply_strict_keyword_matching(df)
        
        # Save results
        output_path = f"{os.path.splitext(file_path)[0]}_classified.xlsx"
        df.to_excel(output_path, index=False)
        
        self.log_message(f"Classification completed: {output_path}", socketio=socketio)
        return output_path

    def apply_strict_keyword_matching(self, df):
        """Apply strict keyword validation"""
        final_keywords = []
        for _, row in df.iterrows():
            processed = row.get('processed_text', '')
            raw_kw = row.get('Keyword', '-')
            
            if not raw_kw or str(raw_kw).strip() in ['-', 'None', 'none', 'NULL']:
                final_keywords.append('-')
                continue
                
            candidates = normalize_candidate_keywords(str(raw_kw))
            chosen = None
            
            for cand in candidates:
                if keyword_present_in_text(processed, cand):
                    chosen = cand
                    break
                    
            final_keywords.append(chosen or '-')
            
        df['Keyword'] = final_keywords
        return df

# ==================== UTILITY FUNCTIONS ====================

def preprocess_text(text):
    if pd.isna(text) or not isinstance(text, str):
        return ""
        
    # Remove URLs but preserve important keywords
    text = re.sub(r'http[s]?://\S+', '', text)
    
    # Convert to lowercase but preserve common acronyms
    common_acronyms = ['sks', 'krs', 'bpp', 'ukt', 'khs', 'sp2', 'sp3', 'ssw', 'sso', 'lms', 'ktm', 'msib', 'kp','puti','kipk','feb','fkb','ksm','pkkmb','cbt','skpi','eprt', 'sirama', 'tult', 'prs','bap', 'lak', 'mbkm', 'fri', 'mbti', 'nik', 'sk', 'fik', 'ftif', 'toss']
    text_lower = text.lower()
    for acronym in common_acronyms:
        if acronym in text_lower:
            text_lower = text_lower.replace(acronym, acronym.upper())
    text = text_lower
    
    # Standardize variations of common terms
    replacements = {
        'igracias': 'igracias',
        'i-gracias': 'igracias',
        'tel-u': 'telyu',
        'telu': 'telyu',
        'tel u': 'telyu',
        'skrg': 'sekarang',
        'semester': 'semester',
        'smstr': 'semester',
        'sem': 'semester',
        'ttp' : 'tetap',
        'tp' : 'tapi',
        'twt' : 'twitter',
        'kk' : 'kakak',
        'pen' : 'pengen',
        'abg' : 'abang',
        'ga' : 'tidak',
        'gt' : 'gitu',
        'ak' : 'aku',
        'trs' : 'terus',
        'krn' : 'karena',
        'kpn' : 'kapan',
        'sm' : 'sama',
        'gmn' : 'gimana',
        'dgn' : 'dengan',
        'sy' : 'saya',
        'dlm' : 'dalam',
        'org' : 'orang',
        'bg' : 'bang',
        'diacc' : 'di accept',
        'bukber' : 'buka bersama',
        'bsk' : 'besok',
        'bs' : 'bisa',
        'bgt' : 'banget',
        'pls' : 'please',
        'tbtb' : 'tiba tiba',
        'jgn' : 'jangan',
        'omg' : 'oh my god',
        'ta' : 'tugas akhir',
        'gw' : 'saya',
        'hp' : 'handphone',
        'wkt' : 'waktu',
        'sertif' : 'sertifikat',
        'gasi' : 'nggak sih',
        'yudis' : 'yudisium',
        'proker' : 'program kerja',
        'matkul' : 'mata kuliah',
        'sk' : 'surat keterangan',
        'mk' : 'mata kuliah',
        'waldos' : 'wali dosen',
        'dospen' : 'dosen pembimbing',
        'fri' : 'fakultas rekaraya industri',
        'feb' : 'fakultas ekonomi bisnis',
        'fik' : 'fakultas ilmu komputer',
        'fkb' : 'fakultas komunikasi bisnis',
        'nik' : 'nomor induk kependudukan'
    }
    for old, new in replacements.items():
        text = re.sub(r'\b' + re.escape(old) + r'\b', new, text)
    
    # Clean punctuation but preserve sentence structure
    text = re.sub(r'[^\w\s-]', ' ', text)
    
    # Normalize whitespace
    text = ' '.join(text.split())
    
    print(f"Preprocessed text example: {text[:50]}...")
    return text

def parse_llm_output(output):
    """Parser yang lebih smart untuk handle multiple formats"""
    print("=" * 60)
    print("🔍 PARSING LLM OUTPUT")
    print("=" * 60)
    print(f"RAW OUTPUT:\n{output}")
    print("=" * 60)
    
    # List valid direktorats
    valid_direktorats = [
        "Akademik",
        "Pasca Sarjana dan Advance Learning", 
        "Aset & Sustainability",
        "Keuangan",
        "Sumber Daya Manusia",
        "Pusat Teknologi Informasi",
        "Kemahasiswaan, Pengembangan Karir, Alumni"
    ]
    
    # Patterns - URUTAN PENTING! Yang lebih spesifik dulu
    patterns = [
        # Pattern untuk jawaban aktual (setelah "JAWABAN:")
        r'JAWABAN:.*?→\s*Direktorat:\s*([^,\n]+?)\s*(?:,|\n)\s*Keyword:\s*([^\n]+)',
        r'jawaban:.*?→\s*Direktorat:\s*([^,\n]+?)\s*(?:,|\n)\s*Keyword:\s*([^\n]+)',
        r'Jawaban:.*?→\s*Direktorat:\s*([^,\n]+?)\s*(?:,|\n)\s*Keyword:\s*([^\n]+)',
        
        # Pattern untuk format final
        r'→\s*Direktorat:\s*([^,\n]+?)\s*(?:,|\n)\s*Keyword:\s*([^\n]+)',
        r'Direktorat:\s*([^,\n]+?)\s*(?:,|\n)\s*Keyword:\s*([^\n]+)',
    ]
    
    direktorat = "Uncategorized"
    keyword = "-"
    
    # Cari pattern yang match - prioritaskan yang ada "JAWABAN"
    for pattern in patterns:
        matches = re.findall(pattern, output, re.IGNORECASE | re.MULTILINE | re.DOTALL)
        if matches:
            print(f"✅ Found {len(matches)} matches with pattern: {pattern}")
            
            # Ambil match TERAKHIR (biasanya yang paling relevan)
            for match in matches:
                raw_direktorat = match[0].strip()
                current_keyword = match[1].strip()
                
                # Skip template patterns seperti [nama], [kata_kunci]
                if re.match(r'\[.*\]', raw_direktorat) or re.match(r'\[.*\]', current_keyword):
                    print(f"⏩ Skipping template: '{raw_direktorat}', '{current_keyword}'")
                    continue
                
                # Skip jika terlalu pendek atau generic
                if len(raw_direktorat) < 3 or raw_direktorat.lower() in ['nama', 'direktorat']:
                    print(f"⏩ Skipping generic: '{raw_direktorat}'")
                    continue
                
                print(f"📥 Considering - Direktorat: '{raw_direktorat}', Keyword: '{current_keyword}'")
                
                normalized = normalize_direktorat_name(raw_direktorat)
                if normalized != "Uncategorized":
                    direktorat = normalized
                    keyword = current_keyword
                    print(f"🎯 Selected: '{direktorat}' with keyword: '{keyword}'")
                    break
            
            if direktorat != "Uncategorized":
                break
    
    # Fallback: cari direktorat yang disebut dalam penjelasan
    if direktorat == "Uncategorized":
        print("🔄 Fallback: Searching for direktorat mentions...")
        for valid_dir in valid_direktorats:
            if valid_dir.lower() in output.lower():
                direktorat = valid_dir
                print(f"✅ Found direktorat mention: '{direktorat}'")
                
                # Cari keyword near the mention
                keyword = extract_keyword_near_mention(output, valid_dir)
                break
    
    # Clean keyword
    keyword = clean_keyword(keyword)
    
    print(f"🎯 FINAL RESULT: Direktorat='{direktorat}', Keyword='{keyword}'")
    print("=" * 60)
    
    return direktorat, keyword

def extract_keyword_near_mention(output, direktorat_mentioned):
    """Extract keyword yang dekat dengan mention direktorat"""
    lines = output.split('\n')
    for i, line in enumerate(lines):
        if direktorat_mentioned.lower() in line.lower():
            # Cari line berikutnya yang mungkin mengandung keyword
            for j in range(i, min(i+3, len(lines))):
                if 'keyword' in lines[j].lower() or 'kata kunci' in lines[j].lower():
                    # Extract keyword setelah "Keyword:"
                    keyword_match = re.search(r'Keyword:\s*([^\n,]+)', lines[j], re.IGNORECASE)
                    if keyword_match:
                        return keyword_match.group(1).strip()
    
    return "-"

def normalize_direktorat_name(raw_direktorat):
    """Normalize nama direktorat ke format standar"""
    # Mapping untuk variasi penulisan yang mungkin dihasilkan LLM
    normalization_map = {
        'akademik': 'Akademik',
        'pasca sarjana': 'Pasca Sarjana dan Advance Learning',
        'pasca': 'Pasca Sarjana dan Advance Learning',
        'pasca sarjana dan advance learning': 'Pasca Sarjana dan Advance Learning',
        'pascasarjana': 'Pasca Sarjana dan Advance Learning',
        'aset': 'Aset & Sustainability', 
        'aset sustainability': 'Aset & Sustainability',
        'aset & sustainability': 'Aset & Sustainability',
        'keuangan': 'Keuangan',
        'sdm': 'Sumber Daya Manusia',
        'sumber daya manusia': 'Sumber Daya Manusia',
        'pti': 'Pusat Teknologi Informasi',
        'teknologi informasi': 'Pusat Teknologi Informasi',
        'pusat teknologi informasi': 'Pusat Teknologi Informasi',
        'teknologi': 'Pusat Teknologi Informasi',
        'kemahasiswaan': 'Kemahasiswaan, Pengembangan Karir, Alumni',
        'kemahasiswaan pengembangan karir alumni': 'Kemahasiswaan, Pengembangan Karir, Alumni',
        'kemahasiswaan, pengembangan karir, alumni': 'Kemahasiswaan, Pengembangan Karir, Alumni',
        'kemahasiswaan dan pengembangan karir': 'Kemahasiswaan, Pengembangan Karir, Alumni',
    }
    
    normalized = raw_direktorat.lower().strip()
    
    # Cek exact match di mapping
    if normalized in normalization_map:
        return normalization_map[normalized]
    
    # Cek partial match
    for variant, standard in normalization_map.items():
        if variant in normalized or normalized in variant:
            return standard
    
    # Jika tidak ada match, return as-is (akan divalidasi nanti)
    return raw_direktorat

def clean_keyword(keyword):
    """Bersihkan keyword dari karakter yang tidak diinginkan"""
    if not keyword or keyword.lower() in ['-', 'none', 'null', 'nan']:
        return "-"
    
    # Remove punctuation dan extra spaces
    keyword = re.sub(r'[^\w\s-]', '', keyword)
    keyword = ' '.join(keyword.split())
    
    return keyword

def get_valid_keywords():
    keywords = set()
    try:
        # Try to parse the keywords component content
        keyword_comp = None
        try:
            # try to get existing active config components
            active = prompt_manager.get_active_config()
            if active:
                comps = prompt_manager.get_config_components(active.id)
                for c in comps:
                    if c.component_type == 'keywords':
                        keyword_comp = c.content
                        break
        except Exception:
            # fallback to default_components dictionary if present
            if hasattr(prompt_manager, 'default_components') and 'keywords' in prompt_manager.default_components:
                keyword_comp = prompt_manager.default_components['keywords']['default_content']
        
        if keyword_comp:
            # Find lines after ":" that contain keywords
            parts = re.split(r'\n|\r', keyword_comp)
            for line in parts:
                if ':' in line:
                    # take substring after ':'
                    _, after = line.split(':', 1)
                    # split by commas
                    pieces = re.split(r',|;', after)
                    for p in pieces:
                        w = p.strip()
                        # filter short empty tokens
                        if len(w) >= 2:
                            # remove words like "Keywords" if present
                            w = re.sub(r'Keywords|Primary Keywords|Secondary Keywords|Direktorat', '', w, flags=re.IGNORECASE).strip()
                            if w:
                                # some tokens are phrases; include them lowercased
                                keywords.add(w.lower())
        # fallback manual list if still empty
        if not keywords:
            manual = [
                'krs','nilai','transkrip','perkuliahan','mata kuliah','sks','cuti akademik','rps','perwalian',
                'ipk','jadwal','semester','s2','s3','wisuda','wifi','password','parkiran','parkir','gedung',
                'bpp','biaya','bayar','dosen','mahasiswa','staff','lms','puti','igracias','ktm',
                'magang','msib','kp','puti','igracias','tugas akhir','registrasi akademik'
            ]
            keywords.update([k.lower() for k in manual])
    except Exception as e:
        # worst-case fallback
        keywords = {
            'krs','nilai','transkrip','perkuliahan','sks','cuti akademik','rps','perwalian',
            'ipk','jadwal','semester','s2','s3','wisuda','wifi','password','parkiran','parkir','gedung',
            'bpp','biaya','bayar','dosen','mahasiswa','staff','lms','puti','igracias','ktm',
            'magang','msib','kp'
        }
    return set(k.lower() for k in keywords)

VALID_KEYWORDS = get_valid_keywords()

def normalize_candidate_keywords(keyword_str):
    """
    Split keyword string returned by LLM into candidate keywords.
    Accepts separators: ',', ';', '/', '|' and returns stripped list.
    """
    if not keyword_str or keyword_str.strip() in ['-', 'none', 'None', 'NULL']:
        return []
    # Remove surrounding quotes
    kw = keyword_str.strip().strip('"').strip("'")
    # split
    parts = re.split(r',|;|/|\||\band\b', kw)
    candidates = [p.strip() for p in parts if p and p.strip() != '']
    return candidates

def keyword_present_in_text(processed_text, candidate):
    """
    Check presence using word-boundary for single words; for multi-word phrase, check phrase.
    Case-insensitive. Returns True/False.
    """
    if not candidate:
        return False
    t = processed_text.lower()
    c = candidate.lower()
    # exact phrase
    if ' ' in c:
        return c in t
    # for single token, use word boundary
    return re.search(r'\b' + re.escape(c) + r'\b', t) is not None

def init_llm_universal(model_name=None, ctx_size_override=None):
    """Universal model initializer untuk semua model"""
    
    if not model_name:
        model_name = "Qwen3-4B-Instruct"
    
    # Deteksi model family untuk default settings
    optimizer = UniversalPromptOptimizer()
    profile = optimizer.get_model_profile(model_name)
    
    # Context size: override > model profile > default
    n_ctx = ctx_size_override or profile['optimal_context'] or 4096
    
    # Cari model path
    potential_paths = [
        f"model/{model_name}/{model_name}.gguf",
        f"model/{model_name}.gguf",
        os.path.join("model", model_name, f"{model_name}.gguf")
    ]
    
    model_path = None
    for path in potential_paths:
        if os.path.exists(path):
            model_path = path
            break
    
    if not model_path:
        raise ValueError(f"Model {model_name} not found")
    
    # Common parameters untuk semua model
    common_params = {
        'model_path': model_path,
        'n_ctx': 8192,  # Context besar untuk prompt panjang
        'n_batch': 512,
        'n_gpu_layers': 25,
        'f16_kv': True,
        'temperature': 0.3,  # Sedikit randomness
        'top_p': 0.9,
        'top_k': 40,
        'n_threads': 8,
        'verbose': False,
        'use_mlock': True,
        'use_mmap': True,
        'seed': 42,
        'repeat_penalty': 1.1,
    }
    
    # Model-specific optimizations
    model_family = optimizer.detect_model_family(model_name)
    
    if model_family in ['qwen', 'qwen2', 'qwen3', 'phi', 'gemma']:
        # Qwen & similar models
        common_params.update({
            'n_gpu_layers': 30,
            'n_threads': 8,
            'rope_freq_base': 10000,
        })
    elif model_family in ['llama', 'llama2', 'llama3']:
        # Llama models
        common_params.update({
            'n_gpu_layers': 35,
            'n_threads': 12,
            'rope_freq_base': 1000000,
        })
    elif model_family in ['mistral', 'mixtral', 'komodo']:
        # Mistral models
        common_params.update({
            'n_gpu_layers': 40,
            'n_threads': 10,
            'rope_freq_base': 10000,
        })
    else:
        # Default settings
        common_params.update({
            'n_gpu_layers': 25,
            'n_threads': 8,
            'rope_freq_base': 10000,
        })
    
    print(f"🚀 Initializing {model_name} | Family: {model_family} | Context: {n_ctx}")
    
    return LlamaCpp(**common_params)

def init_llm(model_name=None):
    """Legacy model initializer - untuk compatibility"""
    return init_llm_universal(model_name)

# ==================== COMPATIBILITY WRAPPERS ====================

# Initialize global instance
classification_system = ClassificationSystem()

# Primary universal function
def classify_universal(file_path, socketio=None, config_id=None, model_name=None, 
                      ctx_size_override=None, benchmark_mode=False, strict_keyword_match=True):
    return classification_system.classify_universal(
        file_path, socketio, config_id, model_name, ctx_size_override, benchmark_mode, strict_keyword_match
    )

# Primary function - HANYA SATU DEFINISI
def classify_dataset(file_path, socketio=None, config_id=None, model_name=None, 
                   strict_keyword_match=True):
    return classification_system.classify_universal(
        file_path, socketio, config_id, model_name, 
        strict_keyword_match=strict_keyword_match
    )

# Qwen-specific function
def classify_with_qwen_optimized(file_path, socketio=None, config_id=None, 
                               model_name="Qwen3-4B-Instruct"):
    return classify_universal(file_path, socketio, config_id, model_name)

# Legacy compatibility
def classify_dataset_legacy(file_path, socketio=None, prompt_id="classify_telkom"):
    return classify_dataset(file_path, socketio, strict_keyword_match=True)