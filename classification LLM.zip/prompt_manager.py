import os
import json
from datetime import datetime  # Add this import
from typing import Dict, List, Optional
from models import db, PromptConfig, PromptComponent

class PromptManager:
    def __init__(self):
        self.default_components = {
            'base': {
                'name': 'Base Template',
                'default_content': """[INST] Anda adalah sistem klasifikasi tingkat lanjut untuk menganalisis keluhan dan pertanyaan mahasiswa Telkom University (disingkat Telyu, Telu, atau Tel-U). 

Tugas: Klasifikasikan teks berikut ke direktorat yang PALING relevan.

Teks: {text}

[/INST]""",
                'order': 0,
                'always_enabled': True
            },
            'instructions': {
                'name': 'Instructions & Rules',
                'default_content': """ATURAN DAN LARANGAN KLASIFIKASI:

ATURAN:
1. Prioritaskan KONTEKS UTAMA dari keluhan/pertanyaan, bukan hanya kata kunci yang muncul
2. Jika ada konflik antara beberapa direktorat, pilih yang paling dominan dalam konteks  
3. Gunakan "Uncategorized" jika benar-benar tidak ada konteks yang cocok
4. Perhatikan kata-kata sekitar untuk menentukan konteks yang tepat
5. Hindari penggunaan "Akademik" untuk kasus yang lebih spesifik ke direktorat lain

LARANGAN:
1. JANGAN membuat direktorat baru di luar 7 yang tersedia
2. JANGAN menambahkan teks lain selain format output yang ditentukan
3. JANGAN mengabaikan konteks hanya karena ada keyword tertentu
4. JANGAN menggunakan "Akademik" sebagai default untuk semua kasus

FORMAT OUTPUT WAJIB: 
Direktorat: [nama_direktorat], Keyword: [keyword_terkait]""",
                'order': 1,
                'always_enabled': False
            },
            'keywords': {
                'name': 'Keywords List',
                'default_content': """DAFTAR KEYWORD DIREKTORAT:

1. Direktorat: Akademik
   Primary Keywords: krs, nilai, transkrip, perkuliahan, mata kuliah, sks, cuti akademik, rps, perwalian, tugas akhir, registrasi akademik
   Secondary Keywords: ipk, jadwal, semester, nilai

2. Direktorat: Pasca Sarjana dan Advance Learning
   Keywords: s2, s3, wisuda, kerja, lowongan, gelar

3. Direktorat: Aset & Sustainability
   Keywords: wifi, password, parkiran, parkir, gedung

4. Direktorat: Keuangan  
   Keywords: bpp, biaya, bayar

5. Direktorat: Sumber Daya Manusia
   Keywords: dosen, mahasiswa, staff, lms

6. Direktorat: Pusat Teknologi Informasi
   Keywords: puti, password, igracias, ktm

7. Direktorat: Kemahasiswaan, Pengembangan Karir, Alumni
   Keywords: magang, msib, kp""",
                'order': 2,
                'always_enabled': False
            },
            'examples': {
                'name': 'Examples',
                'default_content': """CONTOH KLASIFIKASI:

Teks: telyu menurut kalian masih bisa diambil ga yaa niatku mo ambil ps wisuda tp lupa 
→ Direktorat: Pasca Sarjana dan Advance Learning, Keyword: sarjana 

Teks: Telyu! Kalo misalnya krs udah disetujui doswal dari prodi apa masih bisa otak-atik buat drop/hapus mk yang ada?
→ Direktorat: Akademik, Keyword: krs

Teks: Telyu! Ampun Laak Feb Bikin Surat Pengantar Magang lama banget belum lagi ada batasan tanggal nya
→ Direktorat: Kemahasiswaan, Pengembangan Karir, Alumni, Keyword: magang

Teks: telyu ini kenapa dosen pada nggak mau online sih nyebelin banget
→ Direktorat: Sumber Daya Manusia, Keyword: dosen

Teks: Telyu! nii pihak kampus gaada niat untuk perbaiki parkiran tult kahh???
→ Direktorat: Aset & Sustainability, Keyword: parkiran

Teks: telyu! kalo udah bayar bpp harus apa? cara tau matkul smt depan gimana?
→ Direktorat: Keuangan, Keyword: bpp

Teks: telyu kalo ktm digital dipake buat ngebuka palang parkir tuh gabisa ya
→ Direktorat: Pusat Teknologi Informasi, Keyword: ktm digital""",
                'order': 3,
                'always_enabled': False
            }
        }
    
    def initialize_default_config(self):
        """Initialize default prompt configuration"""
        if PromptConfig.query.filter_by(name='Default Config').first():
            return
        
        default_config = PromptConfig(
            name='Default Config',
            description='Konfigurasi prompt default untuk klasifikasi direktorat',
            is_active=True
        )
        db.session.add(default_config)
        db.session.flush()
        
        # Create all components
        for comp_type, comp_info in self.default_components.items():
            component = PromptComponent(
                config_id=default_config.id,
                component_type=comp_type,
                content=comp_info['default_content'],
                is_enabled=not comp_info.get('always_enabled', False),
                order_index=comp_info['order']
            )
            db.session.add(component)
        
        db.session.commit()
    
    def get_active_config(self) -> Optional[PromptConfig]:
        """Get currently active prompt configuration"""
        return PromptConfig.query.filter_by(is_active=True).first()
    
    def get_config_components(self, config_id: int) -> List[PromptComponent]:
        """Get all components for a configuration"""
        return PromptComponent.query.filter_by(
            config_id=config_id
        ).order_by('order_index').all()
    
    def build_prompt(self, text: str, config_id: Optional[int] = None) -> str:
        """Build prompt from database configuration"""
        if not config_id:
            config = self.get_active_config()
            if not config:
                self.initialize_default_config()
                config = self.get_active_config()
            config_id = config.id
        
        components = self.get_config_components(config_id)
        prompt_parts = []
        
        for component in components:
            if component.is_enabled:
                if component.component_type == 'base':
                    # Replace {text} placeholder in base template
                    content = component.content.replace('{text}', text)
                    prompt_parts.append(content)
                else:
                    prompt_parts.append(component.content)
        
        return "\n\n".join(prompt_parts)
    
    def create_new_config(self, name: str, description: str = "", copy_from: Optional[int] = None) -> PromptConfig:
        """Create new prompt configuration"""
        new_config = PromptConfig(
            name=name,
            description=description,
            is_active=False
        )
        db.session.add(new_config)
        db.session.flush()
        
        # Copy components from existing config or use defaults
        if copy_from:
            source_components = self.get_config_components(copy_from)
        else:
            source_components = self.get_config_components(self.get_active_config().id)
        
        for source_comp in source_components:
            new_component = PromptComponent(
                config_id=new_config.id,
                component_type=source_comp.component_type,
                content=source_comp.content,
                is_enabled=source_comp.is_enabled,
                order_index=source_comp.order_index
            )
            db.session.add(new_component)
        
        db.session.commit()
        return new_config
    
    def activate_config(self, config_id: int):
        """Activate a specific configuration"""
        # Deactivate all others
        PromptConfig.query.update({PromptConfig.is_active: False})
        
        # Activate selected one
        config = PromptConfig.query.get(config_id)
        if config:
            config.is_active = True
            db.session.commit()
    
    def update_component(self, component_id: int, content: str = None, is_enabled: bool = None):
        """Update component content and status"""
        try:
            component = PromptComponent.query.get(component_id)
            if component:
                if content is not None:
                    component.content = content
                if is_enabled is not None:
                    component.is_enabled = is_enabled
                component.updated_at = datetime.utcnow()  # PASTIKAN datetime diimport
                db.session.commit()
                return True
            return False
        except Exception as e:
            db.session.rollback()
            print(f"Error in update_component: {str(e)}")
            raise e

# Global prompt manager instance
prompt_manager = PromptManager()